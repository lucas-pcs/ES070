//#include <Wire.h> 
//#include <LiquidCrystal_I2C.h>
//
//void setup()
//{
//  lcd.begin (16,2);
//}
// 
//void loop()
//{
//  lcd.clear();
//  lcd.setCursor(0,0);
//  lcd.print("tecdicas.com");
//  lcd.setCursor(0,1);
//  lcd.print("Modulo I2C");
//  delay(2000);
//  lcd.clear();
//  lcd.setCursor(3, 0);
//  lcd.print("Ola mundo!");
//  delay(1000);
//}
//
//
//// Alterar o endereço conforme modulo I2C
//LiquidCrystal_I2C lcd(0x27, 2,1,0,4,5,6,7,3, POSITIVE); 
//
//
//class Lcd{
//  private:
//    int _Porta;
//    LiquidCrystal_I2C *lcd;
//  public:
//    Teclado();
//    char leTeclado();
//};
//
//Lcd::Lcd()
//{
//  lcd = new LiquidCrystal_I2C lcd(0x27, 2,1,0,4,5,6,7,3, POSITIVE); 
//};
//
//char Teclado::leTeclado()
//{
//  char leitura_teclas = teclado_personalizado->getKey(); // Atribui a variavel a leitura do teclado
//  if (leitura_teclas) {                                 // Se alguma tecla foi pressionada
//    return leitura_teclas;
//    Serial.print(leitura_teclas);
//  }
//  else {
//    return ' ';
//  }
//};
